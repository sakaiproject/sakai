/*
* This file contains the page completion functions called by the toolkit
*
* When a page in the SCO is unloaded, the completionCheck() function is called.
* This function determines if the SCO is complete and sets the appropriate SCORM data.
* Different authors may come up with many different ways to decide if a SCO is complete. Some of these
* ways are:
*	The learner has launched the SCO
* 	The learner has reached the last page of the SCO
*	The learner has completed a test (passed or failed)
*	The learner has passed a test
* 	The learner has completed all of the interactions within the SCO
*	The learner has indicated he or she is done with this SCO
*
* You determine the way your SCO will be considred complete by putting your own code
* in the completionCheck() function
*/

/*
* The page is about to be unloaded, this is the last chance to record state information
*	sCompletion - data passed on from the unloadPage() function
*/
function stateCheck(sCompletion) {
}

/*
* Checks for completion - the following code represents some of the ways your SCO can check for completion.
* This function is called everytime a page in the SCO is unloaded.
* Use this code as-is or replace it with your own
*	sCompletion - data passed on from the unloadPage() function
*		"complete" - the SCO is complete
*		"test" - check to see if a test is complete
*		null - mark the SCO as incomplete
*/
function completionCheck(sCompletion) {
	/* see if the page has told us to mark the SCO as complete */
	if (sCompletion == "complete") {
		/* it has, mark the SCO complete */
		setCompletionStatus("completed");
		
		/* view this as a SCO as passed */
		setPassFail("passed");
		
		/* the learner will not return */
		learnerWillReturn(false);
	} else {
		/* in has not, set the SCO to incomplete */
		setCompletionStatus("incomplete");
		
		/* the learner will  return */
		learnerWillReturn(true);
	}	
}