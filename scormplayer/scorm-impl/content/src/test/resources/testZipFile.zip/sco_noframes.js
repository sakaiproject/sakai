/*
* Code use to create SCOs without a frameset
* Copyright 2007 e-Learning Consulting All Rights Reserved
* www.e-learningconsulting.com
* The use of this code is specified by the End-User License Agreement
*/

/* Global variables start with an underscore "_" */
var _sSep = "^^";               /* the separator used to store the suspend data */

/* Global variables used in the API, these should not be modified by the author */
var _bLinkClicked = false; /* this is set to true if the learner clicked on a navigation link */
var _bUnloaded = false;    /* true if we have called the unload page code */
var _bReadState = false;   /* true if we have read in the state information */
var _aState = new Array(); /* an array to hold the state information */

/* FUNCTIONS USED FOR SCOS CREATED WITHOUT A FRAMESET */

/*
* This function is called when the launch page of the SCO is loaded
*	sPage - the name of the HTML file that provides the first page of SCO content
*		Set sPage to "" if you do not want to go to a content page
*	returns true if we could find the SCORM API, else false
*/
function initSCO(sPage) {
	/* tell SCORM API we have started the SCO */
	scormInitialize();
	
	/* remember the start time */
	setStartTime();
	
	/* set the suspend data to keep track of the start time */
	stateToSuspendData();
	
	/* see if the first page of the SCO has been provided */
	if (sPage != null) {
		/* it has, see if this is the first time the learner has launched this SCO */
		if (isFirstLaunch()) {
			/* this is the first visit to the SCO, go to the first page */
			showPage(sPage);
		} else {
			/* a repeat visit, get the bookmark */
			var sBookmark = getBookmark();
		
			/* go to the bookmarked page */
			showPage(sBookmark);
		}
	}

	/* return true if we could find the SCORM API else false */
	return (apiHandle != null);
}

/*
* Called by every page in the SCO when it is unloaded
* This function saves the state information and decides if we are terminating the SCO session
* 	sParams - passed onto the completionCheck() function
*/
function unloadPage(sParam) {
	/* see if we have already called this function */
	if (!_bUnloaded) {
		/* we have not, so set this var to make sure we do this only once */
		_bUnloaded = true;
		
		/* give the page a chance to update state */
		stateCheck(sParam);
		
		/* see if we are navigating to another page from a link */
		if (!_bLinkClicked) {
			/* we are not navigating from a link, this happens when */
			/* the learner closes the window or has navigated to another SCO using the LMS */
			
			/* call the author defined SCO completion function to allow final SCO activity */
			completionCheck(sParam);
		}
		
		/* get the relative URL of this page */
		var sPage = self.location.href;
		sPage = sPage.substring(sPage.lastIndexOf("\/") + 1);
	
		/* set the bookmark to the name of this page */
		setBookmark(sPage);
		
		/* set the suspend data found in the state array */
		stateToSuspendData();
		
		/* see if we are navigating to another page from a link */
		if (!_bLinkClicked) {
			/* get the start time */
			var sTime = getState("startTime");
			
			/* record the session time */
			setSessionTime(sTime-0);
			
			/* tell SCORM we are done with this SCO session */
			scormTerminate();
		}		
	}
}

/*
* Go to the HTML page without causing the end of the SCO session
*	sPage - the name of the HTML page
*/
function gotoPage(sPage) {
	/* remember that a link was clicked, we do this so we will not terminate the SCO session */
	_bLinkClicked = true;
	
	/* go to the passed page */
	self.location.replace(sPage);
	return false;
}

/*
* Remember a state value associated with this id
* The state information is held in a javascript array
*/
function setState(sId,sValue) {
	/* make sure the state data is loaded */
	loadState();
	
	/* set the state */
	_aState[sId] = sValue;
}

/*
* Get the state value of this id
*/
function getState(sId) {
	/* make sure the state data is loaded */
	loadState();
	
	/* see if there is an ID in the state array */
	if (_aState[sId]) {
		/* there is, return it */
		return _aState[sId];
	} else {
		/* there is no ID, return an empty string */
		return "";
	}
}

/*
* Remember the start time of this SCO
*/
function setStartTime() {
	/* get the date */
	var dateStart = startSessionTime();
	
	/* calc the current timeand save it in the state array */	
	setState("startTime", dateStart.getTime() + "");
}

/*
* Get the elapsed time
*	timePrevious - the starting time as returned by the JavaScript function date.getTime()
*/
function getElapsedTime(timePrevious) {
	/* get the current time */
	var dateNow = new Date();
	var timeNow = dateNow.getTime();
	
	/* calculate the elapsed time from the previous time to now */
	var timeElapsed = Math.round((timeNow - timePrevious) / 1000);
	
	/* format the elapsed time */
	return formatTime(timeElapsed);
}

/*
* Show the page of the SCO
*	sPage - the name of the HTML file to show
*/
function showPage(sPage) {
	/* see if we have a page to jump to */
	if (sPage != "") {
		/* we do, jump to that page */
		self.location.replace(sPage);
	}
}

/*
* Set the suspend data
* we do this by flattening the data stored in the state array
*/
function stateToSuspendData() {
	/* buffer for the state arrray */
	var sSuspend = "";
	
	/* loop through the array */
	for (var i in _aState) {
		sSuspend += i + _sSep + _aState[i] + _sSep;
	}
	
	/* see if there is any data to set */
	/* we will have data to set if there was state information set on this page */
	if (sSuspend != "") {	
		/* there is, store this with SCORM */
		setSuspendData(sSuspend);
	}
}

/*
* Load the suspend data into our state array
*/
function loadState() {
	/* see if we have read in information from suspend data */
	if (!_bReadState) {
		/* we have not, read it in now */
		_bReadState = true;
		var sSuspend = getSuspendData();
		
		/* load the data into a temp array */
		var aParts = sSuspend.split(_sSep);
		
		/* loop through the array */
		for (var i=0; i<aParts.length; i=i+2) {
			/* see if we have an id */
			if (aParts[i] != "") {
				/* we do, copy the data to the state array */
				_aState[ aParts[i] ] = aParts[i+1];
			}
		}
	}
}