/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.pluto.descriptors.servlet;

import java.util.ArrayList;
import java.util.List;

/**
 * Models the &lt;jsp-config&gt; element of a servlet
 * 2.4 deployment descriptor.
 */
public class JspConfigDD
{    
    private List /*TaglibDD*/ taglibs = new ArrayList();
    private List /*JspPropertyGroupDD*/ jspPropertyGroups = new ArrayList();
    
    public List getTaglibs()
    {
        return taglibs;
    }
    
    public void setTaglibs( List taglibs )
    {
        this.taglibs = taglibs;
    }
    
    public List getJspPropertyGroups()
    {
        return jspPropertyGroups;
    }
    
    public void setJspPropertyGroups( List jspPropertyGroups )
    {
        this.jspPropertyGroups = jspPropertyGroups;
    }
}
