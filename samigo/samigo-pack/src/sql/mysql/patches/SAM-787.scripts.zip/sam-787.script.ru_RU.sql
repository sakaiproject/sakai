update sam_answer_t set text='st_yes'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Да');
update sam_answer_t set text='st_no'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Нет');
update sam_answer_t set text='st_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Согласен');
update sam_answer_t set text='st_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Не согласен');
update sam_answer_t set text='st_undecided'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Затрудняюсь ответить');
update sam_answer_t set text='st_below_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Ниже среднего ');
update sam_answer_t set text='st_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Средне ');
update sam_answer_t set text='st_above_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Выше среднего');
update sam_answer_t set text='st_strongly_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Категорически не согласен');
update sam_answer_t set text='st_strongly_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Полностью согласен');
update sam_answer_t set text='st_unacceptable'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Неприемлемо');
update sam_answer_t set text='st_excellent'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Отлично');
