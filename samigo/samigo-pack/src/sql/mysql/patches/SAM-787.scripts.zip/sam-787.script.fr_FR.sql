update sam_answer_t set text='st_yes'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Oui');
update sam_answer_t set text='st_no'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Non');
update sam_answer_t set text='st_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Accepter');
update sam_answer_t set text='st_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'En désaccord');
update sam_answer_t set text='st_undecided'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Indécis');
update sam_answer_t set text='st_below_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Sous la moyenne');
update sam_answer_t set text='st_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Moyenne');
update sam_answer_t set text='st_above_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Au-dessus de la moyenne');
update sam_answer_t set text='st_strongly_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Totalement en désaccord');
update sam_answer_t set text='st_strongly_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Totalement en accord');
update sam_answer_t set text='st_unacceptable'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Inacceptable');
update sam_answer_t set text='st_excellent'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Excellent');
