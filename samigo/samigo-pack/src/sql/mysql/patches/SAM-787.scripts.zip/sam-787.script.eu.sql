update sam_answer_t set text='st_yes'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Bai');
update sam_answer_t set text='st_no'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Ez');
update sam_answer_t set text='st_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Ados');
update sam_answer_t set text='st_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Ez ados');
update sam_answer_t set text='st_undecided'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Erabaki gabe');
update sam_answer_t set text='st_below_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Behean batez bestekoa ');
update sam_answer_t set text='st_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Batez bestekoa');
update sam_answer_t set text='st_above_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Goian batez bestekoa');
update sam_answer_t set text='st_strongly_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Batere ez ados');
update sam_answer_t set text='st_strongly_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Oso ados');
update sam_answer_t set text='st_unacceptable'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Onartezin');
update sam_answer_t set text='st_excellent'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Bikain');
