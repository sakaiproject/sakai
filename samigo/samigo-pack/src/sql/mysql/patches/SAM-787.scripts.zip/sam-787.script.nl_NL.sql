update sam_answer_t set text='st_yes'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Ja');
update sam_answer_t set text='st_no'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Nee');
update sam_answer_t set text='st_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Akkoord');
update sam_answer_t set text='st_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Oneens');
update sam_answer_t set text='st_undecided'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Onbeslist');
update sam_answer_t set text='st_below_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Onder het gemiddelde');
update sam_answer_t set text='st_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Gemiddeld');
update sam_answer_t set text='st_above_average'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Bovengemiddeld');
update sam_answer_t set text='st_strongly_disagree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Volledig oneens');
update sam_answer_t set text='st_strongly_agree'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Volledig eens');
update sam_answer_t set text='st_unacceptable'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Onaanvaardbaar');
update sam_answer_t set text='st_excellent'
where answerid in
(select a.answerid from sam_item_t i, sam_answer_t a where i.typeid=3 and a.itemid=i.itemid and a.text = 'Uitmuntend');
