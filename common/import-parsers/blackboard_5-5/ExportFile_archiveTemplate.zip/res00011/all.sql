\* true

/* Setup the HSQLDB username and password for Sakai.              */
/*   To change it, change the username and password here AND in   */
/*   /usr/local/sakai/sakai.properties                            */


CREATE USER sakaiuser PASSWORD "sakaipassword" ADMIN;

/* Create all the tables                                          */

\i /Users/zach/sakai_alias.sql
\i /Users/zach/chef_announcement.sql
\i /Users/zach/chef_assignment.sql
\i /Users/zach/chef_calendar.sql
\i /Users/zach/chef_chat.sql
\i /Users/zach/sakai_cluster.sql
\i /Users/zach/chef_content.sql
\i /Users/zach/chef_digest.sql
\i /Users/zach/chef_discussion.sql
\i /Users/zach/chef_dissertation.sql
\i /Users/zach/chef_event.sql
\i /Users/zach/chef_id.sql
\i /Users/zach/chef_mailarchive.sql
\i /Users/zach/chef_notification.sql
\i /Users/zach/chef_preferences.sql
\i /Users/zach/chef_presence.sql
\i /Users/zach/sakai_realm.sql
\i /Users/zach/sakai_realm_populate.sql
\i /Users/zach/chef_session.sql
\i /Users/zach/sakai_site.sql
\i /Users/zach/sakai_site_populate.sql
\i /Users/zach/sakai_locks.sql
\i /Users/zach/sakai_user.sql

COMMIT;
SHUTDOWN SCRIPT;



